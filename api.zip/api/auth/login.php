<?php
require_once "../utils/response.php";

$data = json_decode(file_get_contents("php://input"), true);
if(empty($data['username']) || empty($data['password'])){
    jsonResponse(["error"=>"username and password required"], 400);
}

$username = $data['username'];
$password = $data['password'];

$user = null;
// try DB
try{
    require_once "../config/database.php";
    $stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$username]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
    if($user){
        $stored = $user['password'];
        if(is_string($stored) && strpos($stored, '$2y$') === 0){
            if(!password_verify($password, $stored)) { jsonResponse(["error"=>"Identifiants invalides"],401); }
        } else {
            if($password !== $stored) { jsonResponse(["error"=>"Identifiants invalides"],401); }
        }
        jsonResponse(["success"=>true, "user"=>["id"=>$user['id'], "role"=>$user['role']]]);
    }
} catch(Throwable $e){
    // fall through to config fallback
}

// fallback to config file
$cfgPath = __DIR__ . '/config/auth.php';
if(file_exists($cfgPath)){
    $cfg = require $cfgPath;
    if(isset($cfg['users'][$username])){
        $stored = $cfg['users'][$username];
        if(is_string($stored) && strpos($stored, '$2y$') === 0){
            if(password_verify($password, $stored)) jsonResponse(["success"=>true, "user"=>["id"=>0, "role"=>'user']]);
        } else {
            if($password === $stored) jsonResponse(["success"=>true, "user"=>["id"=>0, "role"=>'user']]);
        }
    }
}

jsonResponse(["error"=>"Identifiants invalides"],401);
