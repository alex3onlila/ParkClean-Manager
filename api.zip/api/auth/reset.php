<?php
header('Content-Type: application/json; charset=utf-8');
$body = json_decode(file_get_contents('php://input'), true) ?: [];
$user = $body['username'] ?? '';
$token = $body['token'] ?? '';
$new = $body['new_password'] ?? '';
if(!$user || !$token || !$new){ http_response_code(400); echo json_encode(['success'=>false,'message'=>'username, token and new_password required']); exit; }

$resetsFile = __DIR__ . '/../../data/resets.json';
if(!file_exists($resetsFile)){ http_response_code(400); echo json_encode(['success'=>false,'message'=>'no tokens available']); exit; }
$resets = json_decode(file_get_contents($resetsFile), true) ?: [];
if(!isset($resets[$token])){ http_response_code(400); echo json_encode(['success'=>false,'message'=>'invalid token']); exit; }
$entry = $resets[$token];
if($entry['username'] !== $user){ http_response_code(400); echo json_encode(['success'=>false,'message'=>'token does not match user']); exit; }
if(time() > ($entry['expires'] ?? 0)){ unset($resets[$token]); file_put_contents($resetsFile, json_encode($resets, JSON_PRETTY_PRINT)); http_response_code(400); echo json_encode(['success'=>false,'message'=>'token expired']); exit; }

$updated = false;
// Try updating DB users table first
try {
	require_once __DIR__ . '/../config/database.php';
	$stmt = $conn->prepare('UPDATE users SET password = :p WHERE username = :u');
	$hash = password_hash($new, PASSWORD_DEFAULT);
	$stmt->execute([':p'=>$hash, ':u'=>$user]);
	if($stmt->rowCount() > 0) $updated = true;
} catch(Throwable $e){
	// ignore and fallback
}

if(!$updated){
	$cfgPath = __DIR__ . '/../config/auth.php';
	if(!file_exists($cfgPath)){ http_response_code(500); echo json_encode(['success'=>false,'message'=>'auth config missing and DB update failed']); exit; }
	$cfg = require $cfgPath;
	if(!isset($cfg['users'][$user])){ http_response_code(404); echo json_encode(['success'=>false,'message'=>'user not found']); exit; }
	$hash = password_hash($new, PASSWORD_DEFAULT);
	$cfg['users'][$user] = $hash;
	$php = "<?php\nreturn " . var_export($cfg, true) . ";\n";
	if(file_put_contents($cfgPath, $php) === false){ http_response_code(500); echo json_encode(['success'=>false,'message'=>'failed to write config']); exit; }
}

// remove token after use
unset($resets[$token]); file_put_contents($resetsFile, json_encode($resets, JSON_PRETTY_PRINT));

echo json_encode(['success'=>true,'message'=>'mot de passe mis à jour']);
exit;
