<?php
require_once "../config/database.php";

$date = $_GET["date"] ?? date("Y-m-d");

header("Content-Type: text/csv");
header("Content-Disposition: attachment; filename=rapport_$date.csv");

$output = fopen("php://output", "w");

fputcsv($output, ["Immatriculation","Service","Prix","Date"]);

$stmt = $db->prepare("
SELECT v.immatriculation, s.name, e.prix, e.date_entree
FROM entries e
JOIN vehicles v ON v.id = e.vehicle_id
JOIN services s ON s.id = e.service_id
WHERE date(e.date_entree) = ?
");
$stmt->execute([$date]);

while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
    fputcsv($output, $row);
}

fclose($output);
