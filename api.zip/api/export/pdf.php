<?php
require_once "../config/database.php";

$date = $_GET["date"] ?? date("Y-m-d");

$data = $db->prepare("
SELECT v.immatriculation, s.name AS service, e.prix, e.date_entree
FROM entries e
JOIN vehicles v ON v.id = e.vehicle_id
JOIN services s ON s.id = e.service_id
WHERE date(e.date_entree) = ?
");
$data->execute([$date]);

require_once "../../vendor/fpdf/fpdf.php";

$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont("Arial","B",14);
$pdf->Cell(0,10,"Rapport Journalier - $date",0,1);

$pdf->SetFont("Arial","",10);
while ($row = $data->fetch(PDO::FETCH_ASSOC)) {
    $pdf->Cell(40,8,$row["immatriculation"]);
    $pdf->Cell(40,8,$row["service"]);
    $pdf->Cell(30,8,$row["prix"]);
    $pdf->Ln();
}

$pdf->Output();
