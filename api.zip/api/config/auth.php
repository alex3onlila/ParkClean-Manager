<?php
// Simple auth config for development.
// Change the password by updating the hash below.
return [
    'users' => [
        // username => password_hash('admin123')
        'Alex' => '$2y$10$RaDt1zTyCogcxfzje5G9TOh0eFivDz1UWG7JepFTSsTWmahKnbzje'
    ]
];
