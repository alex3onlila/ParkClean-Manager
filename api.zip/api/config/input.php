<?php

function getInput(): array
{
    $data = [];

    // 1. JSON brut
    $raw = file_get_contents("php://input");
    if ($raw) {
        $json = json_decode($raw, true);
        if (is_array($json)) {
            $data = $json;
        }
    }

    // 2. POST classique (form-data / x-www-form-urlencoded)
    if (!empty($_POST)) {
        $data = array_merge($data, $_POST);
    }

    // 3. GET (fallback ultime)
    if (!empty($_GET)) {
        $data = array_merge($data, $_GET);
    }

    return $data;
}
