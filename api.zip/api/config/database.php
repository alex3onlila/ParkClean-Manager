<?php
header('Content-Type: application/json');

try {
    $db_file = __DIR__ . '/../../database/parkclean.db';
    $conn = new PDO("sqlite:" . $db_file);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->exec("PRAGMA foreign_keys = ON");
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>'Erreur connexion DB: '.$e->getMessage()]);
    exit;
}
