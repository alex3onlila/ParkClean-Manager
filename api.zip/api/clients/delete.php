<?php
// api/clients/delete.php
header('Content-Type: application/json');
require '../config/database.php';

// On récupère les données JSON envoyées par ParkCleanAPI.request
$data = json_decode(file_get_contents("php://input"), true);

if(!isset($data['id'])){
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => "ID manquant dans le corps de la requête"]);
    exit;
}

$id = (int)$data['id'];

try {
    // Note: Assurez-vous que votre variable de connexion s'appelle bien $conn ou $pdo
    $stmt = $conn->prepare("DELETE FROM clients WHERE id = :id");
    $stmt->execute([':id' => $id]);
    
    echo json_encode(['success' => true]);
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => "Erreur DB: " . $e->getMessage()]);
}