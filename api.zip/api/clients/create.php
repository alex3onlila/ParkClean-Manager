<?php
require '../config/database.php';
require '../config/input.php';

$data = getInput();

// Validation minimale
if (
    empty($data['nom']) ||
    empty($data['prenom'])
) {
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'error' => 'Champs obligatoires manquants'
    ]);
    exit;
}

$stmt = $conn->prepare("
    INSERT INTO clients
    (nom, prenom, email, telephone, nbr_vehicules, matricules_historique, image)
    VALUES (:nom, :prenom, :email, :telephone, :nbr_vehicules, :matricules_historique, :image)
");

$stmt->execute([
    ':nom' => $data['nom'],
    ':prenom' => $data['prenom'],
    ':email' => $data['email'] ?? null,
    ':telephone' => $data['telephone'] ?? null,
    ':nbr_vehicules' => $data['nbr_vehicules'] ?? null,
    ':matricules_historique' => $data['matricules_historique'] ?? null,
    ':image' => $data['image'] ?? null
]);

echo json_encode([
    'success' => true,
    'id' => $conn->lastInsertId()
]);
