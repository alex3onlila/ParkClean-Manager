<?php
header('Content-Type: application/json');
require '../config/database.php';
require '../utils/response.php';

$data = json_decode(file_get_contents('php://input'), true) ?: [];
$id = isset($data['id']) ? (int)$data['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : null);
if(!$id){
    jsonResponse(['success'=>false,'error'=>'ID manquant'], 400);
}

try{
    $stmt = $conn->prepare("SELECT * FROM clients WHERE id=:id");
    $stmt->execute([':id'=>$id]);
    $client = $stmt->fetch(PDO::FETCH_ASSOC);
    if(!$client){
        http_response_code(404);
        echo json_encode(['success'=>false,'error'=>"Client non trouvé"]);
        exit;
    }
    echo json_encode($client);
}catch(PDOException $e){
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
