<?php
header('Content-Type: application/json');
require '../config/database.php';

$data = json_decode(file_get_contents("php://input"), true);

$required = ['id','nom','prenom','email','telephone','nbr_vehicules','matricules_historique','image'];
foreach($required as $f){
    if(!isset($data[$f]) || $data[$f] === ''){
        http_response_code(400);
        echo json_encode(['success'=>false,'error'=>"Champ manquant: $f"]);
        exit;
    }
}

try{
    $stmt = $conn->prepare("UPDATE clients SET
        nom=:nom, prenom=:prenom, email=:email, telephone=:telephone,
        nbr_vehicules=:nbr_vehicules, matricules_historique=:matricules_historique, image=:image
        WHERE id=:id");
    $stmt->execute([
        ':id'=>$data['id'],
        ':nom'=>$data['nom'],
        ':prenom'=>$data['prenom'],
        ':email'=>$data['email'],
        ':telephone'=>$data['telephone'],
        ':nbr_vehicules'=>$data['nbr_vehicules'],
        ':matricules_historique'=>$data['matricules_historique'],
        ':image'=>$data['image']
    ]);
    echo json_encode(['success'=>true]);
}catch(PDOException $e){
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
