<?php
header('Content-Type: application/json');
require '../config/database.php';

$data = json_decode(file_get_contents("php://input"), true);

$required = ['id','type','prix_lavage'];
foreach($required as $f){
    if(!isset($data[$f]) || $data[$f] === ''){
        http_response_code(400);
        echo json_encode(['success'=>false,'error'=>"Champ manquant: $f"]);
        exit;
    }
}

try{
    $stmt = $conn->prepare("UPDATE vehicle_types SET type=:type, prix_lavage=:prix_lavage WHERE id=:id");
    $stmt->execute([
        ':id'=>$data['id'],
        ':type'=>$data['type'],
        ':prix_lavage'=>$data['prix_lavage']
    ]);
    echo json_encode(['success'=>true]);
}catch(PDOException $e){
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
