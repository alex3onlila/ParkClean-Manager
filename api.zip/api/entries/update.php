<?php
header('Content-Type: application/json');
require '../config/database.php';

$data = json_decode(file_get_contents("php://input"), true);

$required = ['id','vehicle_id','marque','type','immatriculation','categorie','montant_init','montant_recu','montant_restant','obs'];
foreach($required as $f){
    if(!isset($data[$f]) || $data[$f]===''){
        http_response_code(400);
        echo json_encode(['success'=>false,'error'=>"Champ manquant: $f"]);
        exit;
    }
}

// Vérification vehicle_id
$stmtVehicle = $conn->prepare("SELECT id FROM vehicles WHERE id=:id");
$stmtVehicle->execute([':id'=>$data['vehicle_id']]);
if(!$stmtVehicle->fetch()){
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>"Véhicule introuvable"]);
    exit;
}

try{
    $stmt = $conn->prepare("UPDATE entries SET
        vehicle_id=:vehicle_id, marque=:marque, type=:type, immatriculation=:immatriculation,
        categorie=:categorie, montant_init=:montant_init, montant_recu=:montant_recu,
        montant_restant=:montant_restant, obs=:obs
        WHERE id=:id
    ");
    $stmt->execute([
        ':id'=>$data['id'],
        ':vehicle_id'=>$data['vehicle_id'],
        ':marque'=>$data['marque'],
        ':type'=>$data['type'],
        ':immatriculation'=>$data['immatriculation'],
        ':categorie'=>$data['categorie'],
        ':montant_init'=>$data['montant_init'],
        ':montant_recu'=>$data['montant_recu'],
        ':montant_restant'=>$data['montant_restant'],
        ':obs'=>$data['obs']
    ]);
    echo json_encode(['success'=>true]);
}catch(PDOException $e){
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
