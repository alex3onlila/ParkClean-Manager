<?php
header('Content-Type: application/json');
require '../config/database.php';
require '../utils/response.php';

$body = json_decode(file_get_contents('php://input'), true) ?: [];
$vehicle_id = isset($body['vehicle_id']) ? (int)$body['vehicle_id'] : (isset($_GET['vehicle_id']) ? (int)$_GET['vehicle_id'] : null);
$date = isset($body['date']) ? $body['date'] : (isset($_GET['date']) ? $_GET['date'] : null);

try{
    $sql = "SELECT e.*, v.marque AS vehicule_marque, v.immatriculation AS vehicule_immatriculation
            FROM entries e
            JOIN vehicles v ON e.vehicle_id = v.id";
    $conditions = [];
    $params = [];

    if($vehicle_id){
        $conditions[] = "e.vehicle_id=:vehicle_id";
        $params[':vehicle_id']=$vehicle_id;
    }
    if($date){
        $conditions[] = "date(e.date_enregistrement)=:date";
        $params[':date']=$date;
    }
    if($conditions){
        $sql .= " WHERE ".implode(" AND ", $conditions);
    }
    $sql .= " ORDER BY e.id DESC";

    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $entries = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($entries);
}catch(PDOException $e){
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
