<?php
header('Content-Type: application/json');
require '../config/database.php';

$data = json_decode(file_get_contents("php://input"), true);

// Champs obligatoires
$required = ['entry_id','montant','mode_paiement'];
foreach($required as $f){
    if(!isset($data[$f]) || $data[$f] === ''){
        http_response_code(400);
        echo json_encode(['success'=>false,'error'=>"Champ manquant: $f"]);
        exit;
    }
}

// Vérification entry_id
$stmtEntry = $conn->prepare("SELECT id FROM entries WHERE id=:id");
$stmtEntry->execute([':id'=>$data['entry_id']]);
if(!$stmtEntry->fetch()){
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>"Entrée introuvable"]);
    exit;
}

try{
    $stmt = $conn->prepare("INSERT INTO payments (entry_id, montant, mode_paiement) 
                            VALUES (:entry_id, :montant, :mode_paiement)");
    $stmt->execute([
        ':entry_id'=>$data['entry_id'],
        ':montant'=>$data['montant'],
        ':mode_paiement'=>$data['mode_paiement']
    ]);
    echo json_encode(['success'=>true,'id'=>$conn->lastInsertId()]);
}catch(PDOException $e){
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
