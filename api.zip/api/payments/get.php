<?php
header('Content-Type: application/json');
require '../config/database.php';
require '../utils/response.php';

$data = json_decode(file_get_contents('php://input'), true) ?: [];
$id = isset($data['id']) ? (int)$data['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : null);
if(!$id){
    jsonResponse(['success'=>false,'error'=>'ID manquant'], 400);
}

try{
    $stmt = $conn->prepare("
        SELECT p.*, e.immatriculation AS vehicule_immatriculation, e.categorie AS categorie_entry
        FROM payments p
        JOIN entries e ON p.entry_id = e.id
        WHERE p.id=:id
    ");
    $stmt->execute([':id'=>$id]);
    $payment = $stmt->fetch(PDO::FETCH_ASSOC);
    if(!$payment){
        http_response_code(404);
        echo json_encode(['success'=>false,'error'=>"Paiement non trouvé"]);
        exit;
    }
    echo json_encode($payment);
}catch(PDOException $e){
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
