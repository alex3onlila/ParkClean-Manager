<?php
header('Content-Type: application/json');
require '../config/database.php';

$entry_id = isset($_GET['entry_id']) ? (int)$_GET['entry_id'] : null;

try{
    $sql = "SELECT p.*, e.immatriculation AS vehicule_immatriculation, e.categorie AS categorie_entry
            FROM payments p
            JOIN entries e ON p.entry_id = e.id";
    
    $params = [];
    if($entry_id){
        $sql .= " WHERE p.entry_id=:entry_id";
        $params[':entry_id'] = $entry_id;
    }

    $sql .= " ORDER BY p.id DESC";
    $stmt = $conn->prepare($sql);
    $stmt->execute($params);
    $payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($payments);
}catch(PDOException $e){
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
