<?php
header('Content-Type: application/json');
require '../config/database.php';

$data = json_decode(file_get_contents("php://input"), true);

if (!$data || empty($data['immatriculation']) || empty($data['client_id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Données incomplètes']);
    exit;
}

try {
    $stmt = $conn->prepare("INSERT INTO vehicles (client_id, marque, type_id, immatriculation, image) 
                            VALUES (:client_id, :marque, :type_id, :immatriculation, :image)");
    
    $success = $stmt->execute([
        ':client_id'      => $data['client_id'],
        ':marque'         => $data['marque'],
        ':type_id'        => $data['type_id'],
        ':immatriculation'=> strtoupper($data['immatriculation']), // Normalisation
        ':image'          => $data['image'] ?? null
    ]);

    echo json_encode(['success' => true, 'id' => $conn->lastInsertId()]);
} catch(PDOException $e) {
    http_response_code(500);
    $msg = strpos($e->getMessage(), 'UNIQUE') !== false ? 'Cette plaque existe déjà' : $e->getMessage();
    echo json_encode(['success' => false, 'error' => $msg]);
}