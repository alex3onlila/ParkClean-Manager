<?php
header('Content-Type: application/json');
require '../config/database.php';

try {
    // On récupère les infos du véhicule + nom du client + libellé du type
    $sql = "SELECT v.*, 
                   c.nom || ' ' || c.prenom AS client_nom, 
                   vt.type AS type_nom
            FROM vehicles v
            JOIN clients c ON v.client_id = c.id
            JOIN vehicle_types vt ON v.type_id = vt.id
            ORDER BY v.id DESC";
            
    $stmt = $conn->query($sql);
    $vehicles = $stmt->fetchAll(PDO::FETCH_ASSOC);
    echo json_encode($vehicles);
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}