<?php
header('Content-Type: application/json');
require '../config/database.php';

$data = json_decode(file_get_contents("php://input"), true);

if (empty($data['id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'ID manquant']);
    exit;
}

try {
    $stmt = $conn->prepare("UPDATE vehicles SET 
                            client_id = :client_id, 
                            marque = :marque, 
                            type_id = :type_id, 
                            immatriculation = :immatriculation, 
                            image = :image 
                            WHERE id = :id");
    
    $stmt->execute([
        ':id'             => $data['id'],
        ':client_id'      => $data['client_id'],
        ':marque'         => $data['marque'],
        ':type_id'        => $data['type_id'],
        ':immatriculation'=> strtoupper($data['immatriculation']),
        ':image'          => $data['image'] ?? null
    ]);

    echo json_encode(['success' => true]);
} catch(PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}