<?php
header('Content-Type: application/json; charset=utf-8');
require '../config/database.php';

// Supporte à la fois le JSON (POST/PUT) et le paramètre URL (?id=)
$data = json_decode(file_get_contents('php://input'), true) ?: [];
$id = isset($data['id']) ? (int)$data['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : null);

if (!$id) {
    http_response_code(400);
    echo json_encode(['success' => false, 'error' => 'Identifiant du véhicule manquant']);
    exit;
}

try {
    // Requête avec JOINTURES pour récupérer les labels en une seule fois
    $sql = "SELECT v.*, 
                   c.nom AS client_nom, 
                   c.prenom AS client_prenom, 
                   vt.type AS type_nom,
                   vt.prix_lavage
            FROM vehicles v
            JOIN clients c ON v.client_id = c.id
            JOIN vehicle_types vt ON v.type_id = vt.id
            WHERE v.id = :id";
            
    $stmt = $conn->prepare($sql);
    $stmt->execute([':id' => $id]);
    $vehicle = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$vehicle) {
        http_response_code(404);
        echo json_encode(['success' => false, 'error' => 'Véhicule introuvable']);
        exit;
    }

    // Succès : on renvoie l'objet complet
    echo json_encode($vehicle);

} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'error' => 'Erreur de base de données : ' . $e->getMessage()]);
}