<?php
header('Content-Type: application/json');
require '../config/database.php';
require '../utils/response.php';

$data = json_decode(file_get_contents('php://input'), true) ?: [];
$id = isset($data['id']) ? (int)$data['id'] : (isset($_GET['id']) ? (int)$_GET['id'] : null);
if(!$id){
    jsonResponse(['success'=>false,'error'=>'ID manquant'], 400);
}

try{
    $stmt = $conn->prepare("
        SELECT a.*, v.marque AS vehicule_marque, v.immatriculation AS vehicule_immatriculation,
               c.nom AS client_nom, c.prenom AS client_prenom
        FROM abonnements a
        JOIN vehicles v ON a.vehicle_id = v.id
        JOIN clients c ON a.client_id = c.id
        WHERE a.id=:id
    ");
    $stmt->execute([':id'=>$id]);
    $abonnement = $stmt->fetch(PDO::FETCH_ASSOC);
    if(!$abonnement){
        http_response_code(404);
        echo json_encode(['success'=>false,'error'=>"Abonnement non trouvé"]);
        exit;
    }
    echo json_encode($abonnement);
}catch(PDOException $e){
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
