<?php
header('Content-Type: application/json');
require '../config/database.php';

$data = json_decode(file_get_contents("php://input"), true);

$required = ['vehicle_id','client_id','marque','type','immatriculation','categorie','date_debut','date_fin','montant_init','montant_recu','montant_restant','obs'];
foreach($required as $f){
    if(!isset($data[$f]) || $data[$f]===''){
        http_response_code(400);
        echo json_encode(['success'=>false,'error'=>"Champ manquant: $f"]);
        exit;
    }
}

// Vérification vehicle_id
$stmtVehicle = $conn->prepare("SELECT id FROM vehicles WHERE id=:id");
$stmtVehicle->execute([':id'=>$data['vehicle_id']]);
if(!$stmtVehicle->fetch()){
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>"Véhicule introuvable"]);
    exit;
}

// Vérification client_id
$stmtClient = $conn->prepare("SELECT id FROM clients WHERE id=:id");
$stmtClient->execute([':id'=>$data['client_id']]);
if(!$stmtClient->fetch()){
    http_response_code(400);
    echo json_encode(['success'=>false,'error'=>"Client introuvable"]);
    exit;
}

try{
    $stmt = $conn->prepare("INSERT INTO abonnements
        (vehicle_id, client_id, marque, type, immatriculation, categorie, date_debut, date_fin, montant_init, montant_recu, montant_restant, obs)
        VALUES (:vehicle_id, :client_id, :marque, :type, :immatriculation, :categorie, :date_debut, :date_fin, :montant_init, :montant_recu, :montant_restant, :obs)");
    $stmt->execute([
        ':vehicle_id'=>$data['vehicle_id'],
        ':client_id'=>$data['client_id'],
        ':marque'=>$data['marque'],
        ':type'=>$data['type'],
        ':immatriculation'=>$data['immatriculation'],
        ':categorie'=>$data['categorie'],
        ':date_debut'=>$data['date_debut'],
        ':date_fin'=>$data['date_fin'],
        ':montant_init'=>$data['montant_init'],
        ':montant_recu'=>$data['montant_recu'],
        ':montant_restant'=>$data['montant_restant'],
        ':obs'=>$data['obs']
    ]);
    echo json_encode(['success'=>true,'id'=>$conn->lastInsertId()]);
}catch(PDOException $e){
    http_response_code(500);
    echo json_encode(['success'=>false,'error'=>$e->getMessage()]);
}
