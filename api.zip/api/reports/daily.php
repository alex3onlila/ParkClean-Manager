<?php
require_once "../config/database.php";

header("Content-Type: application/json");

$date = $_GET["date"] ?? date("Y-m-d");

$sql = "
SELECT 
  COUNT(e.id) AS total_vehicules,
  SUM(CASE WHEN s.name = 'LAVAGE' THEN 1 ELSE 0 END) AS total_lavage,
  SUM(CASE WHEN s.name = 'GARDIENNAGE' THEN 1 ELSE 0 END) AS total_gardiennage,
  SUM(e.prix) AS chiffre_affaires
FROM entries e
JOIN services s ON s.id = e.service_id
WHERE date(e.date_entree) = ?
";

$stmt = $db->prepare($sql);
$stmt->execute([$date]);

echo json_encode([
    "date" => $date,
    "rapport" => $stmt->fetch(PDO::FETCH_ASSOC)
]);
